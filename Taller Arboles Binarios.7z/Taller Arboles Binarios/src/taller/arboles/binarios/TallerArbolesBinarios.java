/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller.arboles.binarios;

import java.util.Scanner;

/**
 *
 * @author Estudiantes
 */
public class TallerArbolesBinarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArbolBinario arbBin = new ArbolBinario();
        
        for (int i=0; i<5; i++) {
            System.out.print("Por favor ingrese un valor: ");
            arbBin.insertar(sc.nextInt());
        }
        System.out.println(arbBin.buscar(9));
    }
    
}
